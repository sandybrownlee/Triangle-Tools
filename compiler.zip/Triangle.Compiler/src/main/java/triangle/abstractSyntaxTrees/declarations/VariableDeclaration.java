package triangle.abstractSyntaxTrees.declarations;

import triangle.abstractSyntaxTrees.types.TypeDenoter;

public interface VariableDeclaration {

	TypeDenoter getType();
	
}
