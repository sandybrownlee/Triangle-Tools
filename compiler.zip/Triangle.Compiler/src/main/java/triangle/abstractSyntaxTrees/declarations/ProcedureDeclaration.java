package triangle.abstractSyntaxTrees.declarations;

import triangle.abstractSyntaxTrees.formals.FormalParameterSequence;

public interface ProcedureDeclaration {

	FormalParameterSequence getFormals();
	
}
